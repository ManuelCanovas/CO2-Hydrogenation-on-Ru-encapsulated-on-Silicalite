Hi,

In this repository you will find all the atomic position (CONTCAR) and energies (OSZICAR) for all the reactions studied for the CO2 hydrogenation on encapsulated on Silicalite.

Each folder contains a reaction (R1, R2, etc.) with the Reactant, Product and TS. Adsoption and desorption reactions do not include TS.

Sincerely,
Manuel
